package com.morpheus.demo

import com.morpheusdata.core.MorpheusContext
import com.morpheusdata.core.Plugin
import com.morpheusdata.model.Permission
import com.morpheusdata.views.HTMLResponse
import com.morpheusdata.views.JsonResponse
import com.morpheusdata.response.ServiceResponse
import com.morpheusdata.views.ViewModel
import com.morpheusdata.web.PluginController
import com.morpheusdata.web.Route
import groovy.util.logging.Slf4j


@Slf4j
class CustomTabDemoController implements PluginController {

    Plugin plugin
    MorpheusContext morpheus
    String code = "custom-plugin-controller"
    String name = "Custom Plugin Controller"


    CustomTabDemoController(Plugin plugin, MorpheusContext morpheus) {
        this.plugin = plugin
        this.morpheus = morpheus
    }


    @Override
    List<Route> getRoutes() {
        log.info("returning Custom tab routes...")
        def routes = [
                Route.build("/demoPluginController/showDateThingie", "html", Permission.build("admin", "full")),
                Route.build("/demoPluginController/showDateJSThingie", "json", Permission.build("admin", "full"))
        ]
        return routes
    }

    def html(ViewModel<String> model) {
        log.info("TARGET METHOD REACHED")
//        return ServiceResponse.success("Hello World")
//        try {
//            def theDate = model.request.getParameter('showDate')
//            return ServiceResponse.success([
//                    success: true,
//                    message: "Date received from button: $theDate",
//                    theDate: startDate
//            ])
//        } catch (Exception e) {
//            return ServiceResponse.error("Error getting URL Param: $e")
//        }
        return HTMLResponse.success("Hello World")
    }

    def json(ViewModel<Map> model) {
        Map simpleMap = [serverid: "abc-123", other: model.object.someData]
        return JsonResponse.of(simpleMap)
    }



    @Override
    MorpheusContext getMorpheus() {
        return morpheus
    }

    @Override
    Plugin getPlugin() {
        return plugin
    }

    @Override
    String getCode() {
        return code
    }

    @Override
    String getName() {
        return name
    }
}
